<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class EmailsTemp extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->library('ValidateData');
        $this->load->model('EmailTemplate_Model', 'EmailTemplateModel');
    }

public function saveEmail()
{
    // Decode JSON request

    if ($this->input->method(true) !== 'POST') {
        return $this->response->output([
            'flag' => 'F',
            'msg' => 'Invalid request method',
            'statusCode' => 405
        ], 200);
    }


 // decodeRequest populates $_POST with JSON data
 $this->response->decodeRequest();
   $payload = $_POST;


 log_message('debug', 'PAYLOAD: ' . print_r($payload, true));

 if (empty($payload)) {
        return $this->response->output([
            'flag' => 'F',
            'msg' => 'Invalid JSON payload',
            'statusCode' => 400
        ], 200);
    }

 // ✅ Extract values
    $tempName       = $payload['tempName']       ?? '';
    $subjectOfEmail = $payload['subjectOfEmail'] ?? '';
    $emailContent   = $payload['emailContent']   ?? '';
    $emailSource    = $payload['emailSource']    ?? '';
    $smsContent     = $payload['smsContent']     ?? '';
    $userId         = $payload['SadminID']       ?? 1;


    // ✅ Validate HTML
    if (empty(trim($emailContent))) {
        return $this->response->output([
            'flag' => 'F',
            'msg' => 'Email HTML content is required',
            'statusCode' => 422
        ], 200);
    }
   

     // ✅ Prepare DB data
    $data = [
        'tempUniqueID'   => uniqid('TMP'),
        'is_sys_temp'    => 'no',
        'tempName'       => $tempName,
        'subjectOfEmail' => $subjectOfEmail,
        'emailContent'   => $emailContent, // LONGTEXT
        'emailSource'    => $emailSource,  // LONGTEXT
        'smsContent'     => $smsContent,
        'created_by'     => $userId,
        'created_date'   => date('Y-m-d'),
        'status'         => 'active'
    ];

    $this->db->trans_start();
    $inserted = $this->EmailTemplateModel->saveTemplate($data);

    if (!$inserted) {
        $this->db->trans_rollback();
        return $this->response->output([
            'flag' => 'F',
            'msg' => 'Failed to save email template',
            'statusCode' => 500
        ], 200);
    }

    $this->db->trans_commit();

    return $this->response->output([
        'flag' => 'S',
        'msg' => 'Email template saved successfully',
        'statusCode' => 200
    ], 200);
}


}
