<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-01-17 02:29:15 --> Config Class Initialized
INFO - 2026-01-17 02:29:15 --> Hooks Class Initialized
DEBUG - 2026-01-17 02:29:15 --> UTF-8 Support Enabled
INFO - 2026-01-17 02:29:15 --> Utf8 Class Initialized
INFO - 2026-01-17 02:29:15 --> URI Class Initialized
INFO - 2026-01-17 02:29:15 --> Router Class Initialized
INFO - 2026-01-17 02:29:15 --> Output Class Initialized
INFO - 2026-01-17 02:29:15 --> Security Class Initialized
DEBUG - 2026-01-17 02:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-17 02:29:15 --> Input Class Initialized
INFO - 2026-01-17 02:29:15 --> Language Class Initialized
INFO - 2026-01-17 02:29:15 --> Loader Class Initialized
INFO - 2026-01-17 02:29:15 --> Helper loaded: url_helper
INFO - 2026-01-17 02:29:15 --> Helper loaded: form_helper
INFO - 2026-01-17 02:29:15 --> Helper loaded: accessheaders_helper
INFO - 2026-01-17 02:29:15 --> Helper loaded: application_helper
INFO - 2026-01-17 02:29:15 --> Helper loaded: date_display_helper
INFO - 2026-01-17 02:29:15 --> Database Driver Class Initialized
INFO - 2026-01-17 02:29:15 --> Model "LoginModel" initialized
INFO - 2026-01-17 02:29:15 --> Model "CommonModel" initialized
DEBUG - 2026-01-17 02:29:15 --> Systemmsg library constructor called
INFO - 2026-01-17 02:29:15 --> Database Forge Class Initialized
INFO - 2026-01-17 02:29:15 --> Controller Class Initialized
INFO - 2026-01-17 02:29:15 --> Model "EmailTemplate_Model" initialized
DEBUG - 2026-01-17 02:29:15 --> PAYLOAD: Array
(
    [SadminID] => 5
    [accessFrom] => mobile
    [tempName] => Welcome Email Template
    [subjectOfEmail] => Welcome to Our Platform
    [smsContent] => Welcome! Thanks for joining us.
    [emailSource] => dummy data
    [emailContent] => <html>
<head>
<title>Test</title>
</head>
</html>
)

DEBUG - 2026-01-17 02:29:15 --> Json class already loaded. Second attempt ignored.
INFO - 2026-01-17 02:32:23 --> Config Class Initialized
INFO - 2026-01-17 02:32:23 --> Hooks Class Initialized
DEBUG - 2026-01-17 02:32:23 --> UTF-8 Support Enabled
INFO - 2026-01-17 02:32:23 --> Utf8 Class Initialized
INFO - 2026-01-17 02:32:23 --> URI Class Initialized
INFO - 2026-01-17 02:32:23 --> Router Class Initialized
INFO - 2026-01-17 02:32:23 --> Output Class Initialized
INFO - 2026-01-17 02:32:23 --> Security Class Initialized
DEBUG - 2026-01-17 02:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-17 02:32:23 --> Input Class Initialized
INFO - 2026-01-17 02:32:23 --> Language Class Initialized
INFO - 2026-01-17 02:32:23 --> Loader Class Initialized
INFO - 2026-01-17 02:32:23 --> Helper loaded: url_helper
INFO - 2026-01-17 02:32:23 --> Helper loaded: form_helper
INFO - 2026-01-17 02:32:23 --> Helper loaded: accessheaders_helper
INFO - 2026-01-17 02:32:23 --> Helper loaded: application_helper
INFO - 2026-01-17 02:32:23 --> Helper loaded: date_display_helper
INFO - 2026-01-17 02:32:23 --> Database Driver Class Initialized
INFO - 2026-01-17 02:32:23 --> Model "LoginModel" initialized
INFO - 2026-01-17 02:32:23 --> Model "CommonModel" initialized
DEBUG - 2026-01-17 02:32:23 --> Systemmsg library constructor called
INFO - 2026-01-17 02:32:23 --> Database Forge Class Initialized
INFO - 2026-01-17 02:32:23 --> Controller Class Initialized
INFO - 2026-01-17 02:32:23 --> Model "EmailTemplate_Model" initialized
DEBUG - 2026-01-17 02:32:23 --> PAYLOAD: Array
(
    [SadminID] => 5
    [accessFrom] => mobile
    [tempName] => Welcome Email Template
    [subjectOfEmail] => Welcome to Our Platform
    [smsContent] => Welcome! Thanks for joining us.
    [emailSource] => dummy data
    [emailContent] => <html>
<head>
<title>Test</title>
</head>
</html>
)

DEBUG - 2026-01-17 02:32:23 --> Json class already loaded. Second attempt ignored.
INFO - 2026-01-17 02:32:54 --> Config Class Initialized
INFO - 2026-01-17 02:32:54 --> Hooks Class Initialized
DEBUG - 2026-01-17 02:32:54 --> UTF-8 Support Enabled
INFO - 2026-01-17 02:32:54 --> Utf8 Class Initialized
INFO - 2026-01-17 02:32:54 --> URI Class Initialized
INFO - 2026-01-17 02:32:54 --> Router Class Initialized
INFO - 2026-01-17 02:32:54 --> Output Class Initialized
INFO - 2026-01-17 02:32:54 --> Security Class Initialized
DEBUG - 2026-01-17 02:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-17 02:32:54 --> Input Class Initialized
INFO - 2026-01-17 02:32:54 --> Language Class Initialized
INFO - 2026-01-17 02:32:54 --> Loader Class Initialized
INFO - 2026-01-17 02:32:54 --> Helper loaded: url_helper
INFO - 2026-01-17 02:32:54 --> Helper loaded: form_helper
INFO - 2026-01-17 02:32:54 --> Helper loaded: accessheaders_helper
INFO - 2026-01-17 02:32:54 --> Helper loaded: application_helper
INFO - 2026-01-17 02:32:54 --> Helper loaded: date_display_helper
INFO - 2026-01-17 02:32:54 --> Database Driver Class Initialized
INFO - 2026-01-17 02:32:54 --> Model "LoginModel" initialized
INFO - 2026-01-17 02:32:54 --> Model "CommonModel" initialized
DEBUG - 2026-01-17 02:32:54 --> Systemmsg library constructor called
INFO - 2026-01-17 02:32:54 --> Database Forge Class Initialized
INFO - 2026-01-17 02:32:54 --> Controller Class Initialized
INFO - 2026-01-17 02:32:54 --> Model "EmailTemplate_Model" initialized
DEBUG - 2026-01-17 02:32:54 --> PAYLOAD: Array
(
    [SadminID] => 5
    [accessFrom] => mobile
    [tempName] => Welcome Email Template
    [subjectOfEmail] => Welcome to Our Platform
    [smsContent] => Welcome! Thanks for joining us.
    [emailSource] => dummy data
    [emailContent] => <html>
<head>
<title>Test</title>
</head>
</html>
)

DEBUG - 2026-01-17 02:32:54 --> Json class already loaded. Second attempt ignored.
